# Sea-Picro Footprints

A KiCad 6 Symbol and Footprint library for Sea-Picro.

Contains schematic symbol, along with normal, flipped, castellated, and castellated + normal footprints.

Please place two folders above your KiCad project for the 3d models to import correctly.

e.g.
```
project_name
	> hardware
		> rev_0
sea-picro-footprints
```